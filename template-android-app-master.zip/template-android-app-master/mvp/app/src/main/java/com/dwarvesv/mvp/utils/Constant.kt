package {{packageName}}.utils

object Constant {
    const val LIMIT = 10
}