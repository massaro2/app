package {{packageName}}.base


interface BasePresenter