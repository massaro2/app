package {{packageName}}.utils

class Keys {

    object BundleKeys {
        const val BUNDLE_PARCELABLE_KEY_DATAMVP = "dataMvp"
    }

    object PreferencesKeys

}
