package {{packageName}}.service

object ApiEndpoint {

    const val BASE_URL = "https://api.github.com"
    const val LOGIN = "LOGIN_API"

}