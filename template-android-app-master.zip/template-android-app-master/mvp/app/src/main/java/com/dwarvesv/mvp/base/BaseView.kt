package {{packageName}}.base

interface BaseView<T> {

    var presenter: T

}
