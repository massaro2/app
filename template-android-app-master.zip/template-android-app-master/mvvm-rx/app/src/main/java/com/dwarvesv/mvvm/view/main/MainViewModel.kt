package {{packageName}}.view.main

import {{packageName}}.view.home.HomeViewModelInputs
import {{packageName}}.view.home.HomeViewModelOutputs

interface HomeViewModelInputs

interface HomeViewModelOutputs

class HomeViewModel
    : HomeViewModelInputs, HomeViewModelOutputs