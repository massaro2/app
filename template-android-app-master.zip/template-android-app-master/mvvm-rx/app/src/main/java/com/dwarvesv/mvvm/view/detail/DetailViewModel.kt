package {{packageName}}.view.detail

interface DetailViewModelInputs

interface DetailViewModelOutputs

class DetailViewModel
    : DetailViewModelInputs, DetailViewModelOutputs