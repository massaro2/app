package {{packageName}}.view.home

import {{packageName}}.view.main.HomeViewModelInputs
import {{packageName}}.view.main.HomeViewModelOutputs

interface HomeViewModelInputs

interface HomeViewModelOutputs

class HomeViewModel
    : HomeViewModelInputs, HomeViewModelOutputs