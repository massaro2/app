package {{packageName}}.util

import {{packageName}}.support.LoadingManager

class FakeLoadingManager : LoadingManager {
    override fun show() {}

    override fun hide() {}
}
