package {{packageName}}.domain.model

data class Product(val id: Long, val title: String, val description: String)
