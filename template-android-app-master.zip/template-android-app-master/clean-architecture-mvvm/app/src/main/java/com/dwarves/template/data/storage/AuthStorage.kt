package {{packageName}}.data.storage

class AuthStorage {

    fun getAccessToken(): String {
        // TODO: implement this
        return ""
    }
}
