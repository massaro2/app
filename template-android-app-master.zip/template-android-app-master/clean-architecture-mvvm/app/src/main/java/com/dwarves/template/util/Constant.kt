package {{packageName}}.util

const val AUTHORIZATION = "AUTHORIZATION"
const val BASE_URL = "http://www.google.com"
const val EMPTY_STRING = ""
